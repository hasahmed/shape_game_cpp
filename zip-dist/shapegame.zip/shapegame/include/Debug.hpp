namespace shapegame {
    class Debug {
    };
}
