namespace shapegame {
    class Debug {
    };
}
