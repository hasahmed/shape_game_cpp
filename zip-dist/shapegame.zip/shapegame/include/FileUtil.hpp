#pragma once
#include <string>

namespace shapegame {

    class FileUtil {
        public:
        static std::string read(std::string path);
    };
}
